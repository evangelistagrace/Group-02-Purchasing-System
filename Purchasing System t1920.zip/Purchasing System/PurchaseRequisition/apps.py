from django.apps import AppConfig


class PurchaseRequisitionConfig(AppConfig):
    name = 'PurchaseRequisition'
