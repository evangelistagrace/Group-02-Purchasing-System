from django.apps import AppConfig


class RequestForQuotationConfig(AppConfig):
    name = 'RequestForQuotation'
