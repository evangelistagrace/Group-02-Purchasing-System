from django.apps import AppConfig


class DeliveryOrderConfig(AppConfig):
    name = 'DeliveryOrder'
