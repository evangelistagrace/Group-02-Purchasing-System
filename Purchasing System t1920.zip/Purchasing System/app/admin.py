from django.contrib import admin
from app.models import Person,Item,Vendor


admin.site.register(Person)
admin.site.register(Vendor)
admin.site.register(Item)
