from django.apps import AppConfig


class PurchaseOrderConfig(AppConfig):
    name = 'PurchaseOrder'
