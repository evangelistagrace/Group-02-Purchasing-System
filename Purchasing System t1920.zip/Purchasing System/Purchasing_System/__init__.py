"""
Package for Purchasing_System.
"""
